package cinema;

public class Cinema {
    public static void main(String[] args) {
        frmMain frm = new frmMain();
        frm.setVisible(true);
    }
}
